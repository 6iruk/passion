from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class User(models.Model):

   #Users last name
   user_name = models.CharField(max_length=50, unique=True)

   #Users first name
   first_name = models.CharField(max_length=50)

   #Users last name
   last_name = models.CharField(max_length=50)

   #Users phone number
   phone = models.CharField(max_length=20)

   #Users E-mail
   email = models.EmailField(max_length=254, null=True, blank=True)

   #Django User object associated with this user
   user = models.OneToOneField(User,  on_delete=models.CASCADE)

   #Users friends
   friends = models.ManyToManyField('self')

   def __str__(self):
      return self.user_name

   def add_friend(self, friend):
      #Add a friend to this user

      return self.friends.add(friend)

class Group(models.Model):

   #Group name
   group_name = models.CharField(max_length=50)

   #Members of this group
   members = models.ManyToManyField('user')

   def __str__(self):
      return self.group_name

   def add_member(self, member):
      #Add a member to this group

      return self.members.add(member)