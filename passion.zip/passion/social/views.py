from django.shortcuts import render, get_object_or_404
from social import models
from django.contrib.auth.models import User
from django. views. decorators. csrf import csrf_exempt
from django.http import HttpResponse
from django.contrib.auth import authenticate, login as auth_login

# Create your views here.

@csrf_exempt
def createUser(request):
    #An endpoint to create user

    if models.User.objects.filter(user_name = request.POST.get('userName')).exists():
        return HttpResponse("{\"status\":0, \"remark\":\"User name taken\"}", content_type='application/json')

    models.User.objects.create(user_name = request.POST.get('userName'),
                                 first_name = request.POST.get('firstName'),
                                 last_name = request.POST.get('lastName'),
                                 phone = request.POST.get('phone'),
                                 email = request.POST.get('email'),
                                 user = User.objects.create_user(request.POST.get('userName'), "", request.POST.get('password')))

    return HttpResponse("{\"status\":1, \"remark\":\"User created\"}", content_type='application/json')

@csrf_exempt
def addFriend(request):
    #An endpoint to add a friend
    
    if not request.user.is_authenticated:
        return HttpResponse("{\"status\":0, \"remark\":\"User not authenticated\"}", content_type='application/json')

    user = get_object_or_404(model.User, user_name=request.POST.get('username'))

    request.user.add_friend(user)

    return HttpResponse("{\"status\":1, \"remark\":\"Friend added\"}", content_type='application/json')

@csrf_exempt
def createGroup(request):
    #An endpoint to create group

    if not request.user.is_authenticated:
        return HttpResponse("{\"status\":0, \"remark\":\"User not authenticated\"}", content_type='application/json')

    models.Group.objects.create(group_name = request.POST.get('groupName'))

    return HttpResponse("{\"status\":1, \"remark\":\"Group created\"}", content_type='application/json')

@csrf_exempt
def joinGroup(request):
    #An endpoint to join a group
    
    if not request.user.is_authenticated:
        return HttpResponse("{\"status\":0, \"remark\":\"User not authenticated\"}", content_type='application/json')

    group = get_object_or_404(models.Group,group_name=request.POST.get('groupName'))
    user = get_object_or_404(models.User, user=request.user)

    group.add_member(user)

    return HttpResponse("{\"status\":1, \"remark\":\"Joined group\"}", content_type='application/json')

@csrf_exempt
def login(request):
    #An endpoint to login user

    user = authenticate(username=request.POST.get('userName'), password=request.POST.get('password'))

    if user is not None:
        auth_login(request, user)

        return HttpResponse("{\"status\":1, \"remark\":\"User logged in\"}", content_type='application/json')
    else:
        return HttpResponse("{\"status\":0, \"remark\":\"Authentication failed\"}", content_type='application/json')
